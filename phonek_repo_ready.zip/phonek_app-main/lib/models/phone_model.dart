class PhoneModel {
  final String id;
  final String title;
  final double priceSDG;
  final String brand;
  final String storage;
  final int batteryHealth;
  final String state;
  final String locality;
  final String sellerPhone;
  final String whatsappNumber;
  final bool isVerifiedStore;
  final List<String> imageUrls;
  final DateTime createdAt;

  PhoneModel({
    required this.id,
    required this.title,
    required this.priceSDG,
    required this.brand,
    required this.storage,
    required this.batteryHealth,
    required this.state,
    required this.locality,
    required this.sellerPhone,
    required this.whatsappNumber,
    this.isVerifiedStore = false,
    required this.imageUrls,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'title': title,
        'priceSDG': priceSDG,
        'brand': brand,
        'storage': storage,
        'batteryHealth': batteryHealth,
        'state': state,
        'locality': locality,
        'sellerPhone': sellerPhone,
        'whatsappNumber': whatsappNumber,
        'isVerifiedStore': isVerifiedStore,
        'imageUrls': imageUrls,
        'createdAt': createdAt.toIso8601String(),
      };

  factory PhoneModel.fromMap(Map<String, dynamic> map, String docId) {
    final rawPrice = map['priceSDG'];
    final rawBattery = map['batteryHealth'];
    final rawDate = map['createdAt'];

    DateTime date = DateTime.now();
    if (rawDate is String) {
      date = DateTime.tryParse(rawDate) ?? date;
    } else if (rawDate != null && rawDate.toString().contains('Timestamp')) {
      try {
        date = rawDate.toDate() as DateTime;
      } catch (_) {}
    }

    return PhoneModel(
      id: docId,
      title: (map['title'] ?? '').toString(),
      priceSDG: rawPrice is num ? rawPrice.toDouble() : double.tryParse('$rawPrice') ?? 0,
      brand: (map['brand'] ?? '').toString(),
      storage: (map['storage'] ?? '').toString(),
      batteryHealth: rawBattery is num ? rawBattery.toInt() : int.tryParse('$rawBattery') ?? 100,
      state: (map['state'] ?? '').toString(),
      locality: (map['locality'] ?? '').toString(),
      sellerPhone: (map['sellerPhone'] ?? '').toString(),
      whatsappNumber: (map['whatsappNumber'] ?? '').toString(),
      isVerifiedStore: map['isVerifiedStore'] == true,
      imageUrls: map['imageUrls'] is List
          ? List<String>.from((map['imageUrls'] as List).map((e) => e.toString()))
          : <String>[],
      createdAt: date,
    );
  }
}
