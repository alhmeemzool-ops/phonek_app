import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/phone_model.dart';

class PhoneKService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Stream<List<PhoneModel>> getPhones() {
    try {
      return _firestore
          .collection('phones')
          .orderBy('createdAt', descending: true)
          .snapshots()
          .map((snapshot) => snapshot.docs
              .map((doc) => PhoneModel.fromMap(doc.data(), doc.id))
              .toList());
    } catch (_) {
      return Stream.value(const <PhoneModel>[]);
    }
  }

  Future<String> addPhone(PhoneModel phone) async {
    final doc = await _firestore.collection('phones').add(phone.toMap());
    return doc.id;
  }

  static Future<void> makePhoneCall(String phoneNumber) async {
    if (phoneNumber.trim().isEmpty) return;
    final uri = Uri(scheme: 'tel', path: phoneNumber.trim());
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  static Future<void> openWhatsApp(String phoneNumber, String title) async {
    final clean = phoneNumber.replaceAll(RegExp(r'\D'), '');
    if (clean.isEmpty) return;
    final message = Uri.encodeComponent('مرحباً، أريد الاستفسار عن $title');
    final uri = Uri.parse('https://wa.me/$clean?text=$message');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }
}
