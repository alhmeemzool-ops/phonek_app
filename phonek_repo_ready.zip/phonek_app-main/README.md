# PhoneK

تطبيق PhoneK لإعلانات الهواتف.

## بناء APK عبر GitHub Actions

1. ارفع محتويات هذا المستودع إلى GitHub.
2. افتح تبويب **Actions**.
3. اختر **Build PhoneK APK**.
4. اضغط **Run workflow** أو ادفع أي commit إلى أي فرع.
5. بعد نجاح البناء افتح الـworkflow ثم **Artifacts** ونزّل ملف APK.

> ملاحظة: مجلد Android غير موجود في النسخة الأصلية، لذلك الـworkflow ينشئ ملفات Android تلقائياً أثناء البناء.

> ملاحظة Firebase: تشغيل قاعدة البيانات يحتاج إعداد Firebase/Google Services الخاص بالمشروع. هذا المستودع لا يحتوي على بيانات اعتماد Firebase.
